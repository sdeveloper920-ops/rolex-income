const admin = require("firebase-admin");
const corsHeaders = {"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"Content-Type, Authorization","Access-Control-Allow-Methods":"POST, OPTIONS"};
function response(status, body){return {statusCode:status,headers:{...corsHeaders,"Content-Type":"application/json"},body:JSON.stringify(body)}}
function init(){if(admin.apps.length)return;const raw=process.env.FIREBASE_SERVICE_ACCOUNT;if(!raw)throw new Error("Netlify environment variable FIREBASE_SERVICE_ACCOUNT সেট করা হয়নি");let cred;try{cred=JSON.parse(raw)}catch{throw new Error("FIREBASE_SERVICE_ACCOUNT-এ valid JSON দিন")}admin.initializeApp({credential:admin.credential.cert(cred),projectId:"rolex-income-4b97f"});}
const ADMIN_EMAIL="sdeveloper920@gmail.com";
exports.handler=async(event)=>{
 if(event.httpMethod==="OPTIONS")return response(200,{ok:true});
 if(event.httpMethod!=="POST")return response(405,{ok:false,error:"POST only"});
 try{
  init();
  const token=(event.headers.authorization||event.headers.Authorization||"").replace(/^Bearer\s+/i,"");
  if(!token) return response(401,{ok:false,error:"Login required"});
  const decoded=await admin.auth().verifyIdToken(token), uid=decoded.uid, email=(decoded.email||"").toLowerCase(), isAdmin=email===ADMIN_EMAIL;
  const db=admin.firestore(), body=event.body?JSON.parse(event.body):{}, action=event.queryStringParameters?.action;
  const userRef=db.collection("users").doc(uid), userSnap=await userRef.get();
  if(!userSnap.exists) await userRef.set({uid,email:decoded.email||"",name:decoded.name||"",balance:0,createdAt:admin.firestore.FieldValue.serverTimestamp(),referralCode:uid.slice(0,8).toUpperCase()});
  const user=(await userRef.get()).data();
  const num=v=>Number.isFinite(Number(v))?Number(v):0;
  const positive=v=>Number.isFinite(Number(v))&&Number(v)>0;
  if(action==="dashboard"){
   const [tasksSnap,histSnap]=await Promise.all([db.collection("tasks").where("active","==",true).get(),db.collection("transactions").where("uid","==",uid).orderBy("createdAt","desc").limit(30).get()]);
   return response(200,{ok:true,isAdmin,balance:user.balance||0,tasks:tasksSnap.docs.map(d=>({id:d.id,...d.data()})),history:histSnap.docs.map(d=>({id:d.id,...d.data(),createdAt:d.data().createdAt?.toDate?.()?.toISOString()||new Date().toISOString()}))});
  }
  if(action==="claimTask"){
   const taskRef=db.collection("tasks").doc(String(body.taskId||"")), taskSnap=await taskRef.get();if(!taskSnap.exists||!taskSnap.data().active)return response(404,{ok:false,error:"Task পাওয়া যায়নি"});
   const task=taskSnap.data(), day=new Date().toISOString().slice(0,10), claimRef=db.collection("claims").doc(uid+"_"+taskRef.id+"_"+day), txRef=db.collection("transactions").doc();
   await db.runTransaction(async tx=>{const [c,u]=await Promise.all([tx.get(claimRef),tx.get(userRef)]);if(c.exists)throw new Error("আজকের Task ইতিমধ্যে claim করেছেন");const bal=num(u.data().balance), reward=num(task.reward);if(!positive(reward))throw new Error("Task reward invalid");tx.create(claimRef,{uid,taskId:taskRef.id,day,createdAt:admin.firestore.FieldValue.serverTimestamp()});tx.update(userRef,{balance:bal+reward});tx.create(txRef,{uid,type:"task_reward",amount:reward,status:"completed",createdAt:admin.firestore.FieldValue.serverTimestamp()});});
   return response(200,{ok:true});
  }
  if(action==="deposit"){
   const amount=num(body.amount);if(!positive(amount)||amount>1000000||!["bKash","Nagad","Rocket"].includes(body.method)||String(body.trxId||"").trim().length<5)return response(400,{ok:false,error:"সঠিক amount, method ও Transaction ID দিন"});
   const ref=await db.collection("requests").add({uid,email:decoded.email||"",type:"deposit",method:body.method,amount,trxId:String(body.trxId).trim(),status:"pending",createdAt:admin.firestore.FieldValue.serverTimestamp()});
   await db.collection("transactions").add({uid,type:"deposit",amount,status:"pending",requestId:ref.id,createdAt:admin.firestore.FieldValue.serverTimestamp()});return response(200,{ok:true});
  }
  if(action==="withdraw"){
   const amount=num(body.amount),number=String(body.number||"").trim();if(!positive(amount)||amount>100000||!/^01[3-9]\d{8}$/.test(number)||!["bKash","Nagad","Rocket"].includes(body.method))return response(400,{ok:false,error:"সঠিক amount, mobile number ও method দিন"});
   const reqRef=db.collection("requests").doc(),txRef=db.collection("transactions").doc();
   await db.runTransaction(async tx=>{const u=await tx.get(userRef),bal=num(u.data().balance);if(bal<amount)throw new Error("পর্যাপ্ত ব্যালেন্স নেই");tx.update(userRef,{balance:bal-amount});tx.create(reqRef,{uid,email:decoded.email||"",type:"withdraw",method:body.method,number,amount,status:"pending",createdAt:admin.firestore.FieldValue.serverTimestamp()});tx.create(txRef,{uid,type:"withdraw",amount,status:"pending",requestId:reqRef.id,createdAt:admin.firestore.FieldValue.serverTimestamp()});});
   return response(200,{ok:true});
  }
  if(action==="adminData"){
   if(!isAdmin)return response(403,{ok:false,error:"Admin only"});
   const [rs,ts]=await Promise.all([db.collection("requests").orderBy("createdAt","desc").limit(100).get(),db.collection("tasks").orderBy("createdAt","desc").get()]);
   return response(200,{ok:true,requests:rs.docs.map(d=>({id:d.id,...d.data()})),tasks:ts.docs.map(d=>({id:d.id,...d.data()}))});
  }
  if(action==="createTask"){
   if(!isAdmin)return response(403,{ok:false,error:"Admin only"});const title=String(body.title||"").trim(),reward=num(body.reward),dailyLimit=Math.floor(num(body.dailyLimit));if(!title||title.length>100||!positive(reward)||reward>10000||dailyLimit<1||dailyLimit>20)return response(400,{ok:false,error:"Task title/reward/limit ঠিক করুন"});
   await db.collection("tasks").add({title,reward,dailyLimit,active:true,createdAt:admin.firestore.FieldValue.serverTimestamp()});return response(200,{ok:true});
  }
  if(action==="toggleTask"){
   if(!isAdmin)return response(403,{ok:false,error:"Admin only"});await db.collection("tasks").doc(String(body.taskId||"")).update({active:!!body.active});return response(200,{ok:true});
  }
  if(action==="review"){
   if(!isAdmin)return response(403,{ok:false,error:"Admin only"});if(!["approve","reject"].includes(body.decision))return response(400,{ok:false,error:"Invalid decision"});
   const reqRef=db.collection("requests").doc(String(body.requestId||""));
   await db.runTransaction(async tx=>{const r=await tx.get(reqRef);if(!r.exists||r.data().status!=="pending")throw new Error("Request নেই বা আগে review হয়েছে");const x=r.data(),uRef=db.collection("users").doc(x.uid),u=await tx.get(uRef),bal=num(u.data().balance);
    if(x.type==="deposit"&&body.decision==="approve")tx.update(uRef,{balance:bal+num(x.amount)});
    if(x.type==="withdraw"&&body.decision==="reject")tx.update(uRef,{balance:bal+num(x.amount)});
    tx.update(reqRef,{status:body.decision==="approve"?"approved":"rejected",reviewedAt:admin.firestore.FieldValue.serverTimestamp(),reviewedBy:email});
    tx.create(db.collection("transactions").doc(),{uid:x.uid,type:x.type,amount:x.amount,status:body.decision==="approve"?"completed":"rejected",requestId:reqRef.id,createdAt:admin.firestore.FieldValue.serverTimestamp()});
   });return response(200,{ok:true});
  }
  return response(404,{ok:false,error:"Unknown action"});
 }catch(e){return response(400,{ok:false,error:e.message||"Server error"});}
};